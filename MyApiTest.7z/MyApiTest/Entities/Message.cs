﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using MyApiTest.Models;

namespace MyApiTest.Entities
{
    public class Message
    {
       // public int UserId { get; set; }
        public User User { get; set; }
        [Key] public int Id { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string Username { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public string Face_url { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Content { get; set; }

        public string Send_timestamp { get; set; }


        /// <summary>
        /// 用户注册时间
        /// </summary>

    }
}
