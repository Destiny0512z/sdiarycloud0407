﻿using MyApiTest.Entities;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
namespace MyApiTest.Entities
{
    public class User//用户基本信息实体模型
    {
        /// <summary>
        /// 用户唯一标识符 主键 自动生成
        /// </summary>
        
        [Key] public int Id { get; set; } 
        

        /// <summary>
        /// 用户名
        /// </summary>
        public string Username { get; set; }


        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 用户注册时间
        /// </summary>
        public string Face_url { get; set; }


    }
}
