﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyApiTest.Entities
{
    public class Follow
    {
        //FollowId是当前用户的Id
        public int FollowId { get; set; }
        //UserId是系统中存在的Id，粉丝
        public int UserId { get; set; }
        public User User { get; set; }


       
    }
}
