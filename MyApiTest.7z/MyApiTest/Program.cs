using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MyApiTest.Persistence;
using Microsoft.Extensions.DependencyInjection;
using MyApiTest.Models;
using System.Net;

namespace MyApiTest
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();
            using (var scope = host.Services.CreateScope())
            {
                var service = scope.ServiceProvider;
                try
                {
                    var context = service.GetRequiredService<MyContext>();
                    if (context.Database.IsMySql())
                    {
                        context.Database.Migrate();
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

            await host.RunAsync();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder
                    .UseStartup<Startup>()
                    .UseKestrel(options => {
                        options.ConfigureHttpsDefaults(o =>
                        {
                            o.ServerCertificate = new System.Security.Cryptography.X509Certificates.X509Certificate2("server.pfx", "W4hTmGJR");
                        });
                    });
                });
    }
}
