﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using MyApiTest.Models;
using MyApiTest.Entities;

namespace MyApiTest.Controllers
{
    [Route("")]
    [ApiController]
    public class TreeholeController : ControllerBase
    {
        private readonly MyContext _context;
        public IList<Message> Messages { get; set; }
        public TreeholeController(MyContext context)
        {
            _context = context;
        }

        [HttpPost("/Add")]
       //新增日志到message表，需要前端调用端口
        public async Task<ActionResult<CommonResult>> Add(AddModel model)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == model.UserId);
            if (user == null)
            {
                throw new Exception("user not exist");
            }
            var messages = new Message();
            messages.User = user;
            messages.User.Id = model.UserId;
            messages.Username = model.Username;
            messages.Face_url = model.Face_url;
            messages.Content = model.Content;
            messages.Send_timestamp = DateTime.Now.ToString();
            _context.Messages.Add(messages);
            await _context.SaveChangesAsync();
            return CommonResult.OK();
        }


        [HttpPost("/GetAllMessages")]
       
        public async Task<ActionResult<IList<Message>>> OnGetAsync()
        {
            //直接返回messages列表
            return await _context.Messages.AsNoTracking().ToListAsync();

        }

        [HttpPost("/GetUserMessages")]
        public async Task<ActionResult<IList<Message>>> GetAsync(GetUserMessages model)
        {
            //返回查询后的user发的消息
            return await _context.Messages.AsNoTracking().Where(x=>x.User.Id==model.UserId).ToListAsync();

        }
        [HttpPost("/DelUserMessages")]

        public async Task<ActionResult<CommonResult>> GetAsync(DelUserMessagesModel model)
        {
            //Messages表里是id，但是CollectMessages表里是messagesid,需要区分
            //这里是messages里的id和传入的model.messageid进行匹配
            var delUserMessages = await _context.Messages.FirstOrDefaultAsync(x=>x.Id==model.MessageId);
            _context.Messages.Remove(delUserMessages);
            await _context.SaveChangesAsync();
            return CommonResult.OK();
        }
    }
    
}
