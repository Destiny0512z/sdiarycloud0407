﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using MyApiTest.Models;
using MyApiTest.Models.Collect;
using MyApiTest.Entities;

namespace MyApiTest.Controllers
{
    [Route("")]
    [ApiController]
    public class CollectMessagesController : Controller
    {
        private readonly MyContext _context;
        //public IList<Message> Messages { get; set; }
        public CollectMessagesController(MyContext context)
        {
            _context = context;
        }

        [HttpPost("/CollectMessages")]
        //收藏到collectmessages表，需要前端调用端口
        public async Task<ActionResult<CommonResult>> CollectMessages(CollectModel model)
        {
            //因为CollectMessages中关联两个实体
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == model.UserId);
            //收藏消息需要先判断是否存在用户和消息
            if (user == null)//用户不存在
            {
                throw new Exception("user not exist");
            }
            var messages = await _context.Messages.FirstOrDefaultAsync(x => x.Id == model.MessageId);//查询是否存在消息
            if (messages == null)//消息不存在
            {
                throw new Exception("messages not exist");
            }
            var collectmessages = new CollectMessage();//新增表数据
            collectmessages.User = user;
            collectmessages.Message = messages;
            collectmessages.User.Id= model.UserId;
            collectmessages.Message.Id = model.MessageId;
            _context.Add(collectmessages);
            await _context.SaveChangesAsync();

            return StatusCode(200);
        }
        
        [HttpPost("/GetUserCollectMessages")]

        public async Task<IList<Message>> GetAsync(GetUserCollectMessages model)
        {       
            //直接返回查询用户收藏的messages列表
            return await _context.CollectMessages
                .AsNoTracking()
                .Where(x => x.UserId == model.UserId)
                .Include(x => x.Message)
                .Select(x => x.Message)
                .ToListAsync(); 

            //throw new NotImplementedException();

        }

        [HttpPost("/DelUserCollectMessages")]

        public async Task<ActionResult<CommonResult>> GetAsync(DelUserCollectMessages model)
        {
            //删除用户收藏消息，根据messageid和userid确定消息进行删除
            var delUserCollectMessages = await _context.CollectMessages
                .Where(x => x.MessageId == model.MessageId &&  x.UserId == model.UserId)
                .FirstOrDefaultAsync();


            _context.CollectMessages.Remove(delUserCollectMessages);

            await _context.SaveChangesAsync();
            return CommonResult.OK();
        }

    }
}
