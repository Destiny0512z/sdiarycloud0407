﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyApiTest.Entities;
using MyApiTest.Models;
using MyApiTest.Models.Follow;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace MyApiTest.Controllers
{
    public class FollowController : Controller
    {
        private readonly MyContext _context;
        //public IList<Message> Messages { get; set; }
        public FollowController(MyContext context)
        {
            _context = context;
        }


        [HttpPost("/Follow")]
        //收藏到collectmessages表，需要前端调用端口
        public async Task<ActionResult<CommonResult>> Follow(FollowModel model)
        {
            
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == model.UserId);
            //收藏消息需要先判断是否存在用户和消息
           
            var follower = new Follow();//新增表数据
            follower.User = user;
            follower.User.Id = model.UserId;
            follower.FollowId= model.FollowId;
            
            _context.Add(follower);
            await _context.SaveChangesAsync();
            /**/

            
            return StatusCode(200);
        }
        /**/
        [HttpPost("/GetFollowers")]

        public async Task<IList<GetFollowersResult>> GetAsync(GetFollowers model)
        {
            //传入FollowId是粉丝Id,UserId是用户Id,粉丝关注用户后，插入表中
            //查询粉丝功能，能够反映双方的关注和被关注状态，输入FollowId后可以返回粉丝信息
            return await _context.Followers
                .AsNoTracking()
                .Where(x => x.FollowId == model.FollowId)
                .Include(x => x.User)
                .Select(x => new GetFollowersResult { Username = x.User.Username,Face_url=x.User.Face_url})
                .ToListAsync();
            
            //throw new NotImplementedException();
        }

        [HttpPost("/CancelFollowers")]

        public async Task<ActionResult<CommonResult>> GetAsync(CancelFollowers model)
        {
            //删除用户收藏消息，根据messageid和userid确定消息进行删除
            var cancel = await _context.Followers
                .Where(x => x.FollowId == model.FollowId && x.UserId == model.UserId)
                .FirstOrDefaultAsync();


            _context.Followers.Remove(cancel);

            await _context.SaveChangesAsync();
            return CommonResult.OK();
        }

    }
}
