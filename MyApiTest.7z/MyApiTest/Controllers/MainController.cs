﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyApiTest.Entities;
using MyApiTest.Models;

namespace MyApiTest.Controllers
{
    [Route("")]
    [ApiController]
    public class MainController : ControllerBase
    {
        private readonly MyContext _context;

        public MainController(MyContext context)
        {
            _context = context;
        }

        [HttpPost("/login")]//登录提交判断
        public async Task<ActionResult<LoginResult>> Login(LoginModel model)//传loginModel模型命名为loginModel，包含username和password
        {
            var user = await _context.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Phone == model.Phone);
            //声明user变量，只读数据，从User表里查询Phone字段，查找model.Phone的匹配值 ，如果有匹配值，将第一条数据给user
            if (user == null)//如果user为空,之前没有匹配值，返回403
                return StatusCode(403);
            else if (user.Password == model.Password)//名字配对上后，比对查到的user密码和模型密码
            {
               
                return new LoginResult
                {
                    User_Id = user.Id,
                    Username = user.Username,
                    Phone = user.Phone,
                    Face_url = user.Face_url
                };
            }
            else
            {
                return StatusCode(403);
            }
        }

        
        [HttpPost("/regist")]
        public async Task<ActionResult<RegistResult>> Regist(RegistModel model)
        {
            var check = await _context.Users.AsNoTracking().FirstOrDefaultAsync(x => x.Phone == model.Phone);
            //先判断手机号是否存在
            if (check == null)
            {
                var user = new User();

                user.Username = model.Username;
                user.Phone = model.Phone;
                user.Password = model.Password;
                user.Face_url = model.Face_url;
                _context.Users.Add(user);

                await _context.SaveChangesAsync();
                return new RegistResult
                {
                    Username = user.Username,
                    Phone = user.Phone,
                    Password = user.Password,
                    Face_url = user.Face_url
                };

            }
            else
            {

                throw new Exception("Phone already exists");  


            }
           

        }
    }
}
