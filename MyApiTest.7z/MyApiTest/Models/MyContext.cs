﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MyApiTest.Entities;
using MyApiTest.Models;

namespace MyApiTest.Models
{
    public class MyContext : DbContext
    {
        public MyContext(DbContextOptions<MyContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }

        public DbSet<Message> Messages { get; set; }

        public DbSet<CollectMessage> CollectMessages{ get; set; }
        public DbSet<MyApiTest.Entities.Follow> Followers{ get; set; }
        
        
         
        

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            //CollectMessages表和另外两个表的关系
            base.OnModelCreating(modelBuilder);

            //实体CollectMessage每个message对应多个用户，有一个外键MessageId,是必填值
            modelBuilder.Entity<CollectMessage>().HasOne(x => x.Message).WithMany().HasForeignKey(x => x.MessageId).IsRequired();

             //实体CollectMessage每个User表是一对多的关系，有一个外键UserId,是必填值
            modelBuilder.Entity<CollectMessage>().HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).IsRequired();

            modelBuilder.Entity<Entities.Follow>().HasOne(x=>x.User).WithMany().HasForeignKey(x => x.UserId).IsRequired();

            //设置两个主键
            modelBuilder.Entity<CollectMessage>().HasKey(x => new {x.MessageId,x.UserId });
            modelBuilder.Entity<Entities.Follow>().HasKey(x => new {x.FollowId,x.UserId });
            
        }
        //  public DbSet<UserAuthentication> Tokens { get; set; }



    }
}
