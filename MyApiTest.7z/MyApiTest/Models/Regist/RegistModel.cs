﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace MyApiTest.Models
{
    public class RegistModel
    {
        /// <summary>
        /// 用户名
        /// </summary>
        public string Username { get; set; }


        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }
        public string Password_again{ get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        [Key]public string Phone { get; set; }

        public string Face_url { get; set; }
    }
}

