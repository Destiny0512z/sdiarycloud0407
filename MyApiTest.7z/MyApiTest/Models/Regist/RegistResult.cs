﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace MyApiTest.Models
{
    public class RegistResult
    {
        public string Username { get; set; }


        /// <summary>
        /// 密码
        /// </summary>
        public string Password { get; set; }
        

        /// <summary>
        /// 手机号
        /// </summary>
        [Key] public string Phone { get; set; }

        public string Face_url { get; set; }
    }
}
