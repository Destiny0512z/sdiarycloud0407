﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace MyApiTest.Models
{
    public class LoginResult
    {
        /// <summary>
        /// 用户唯一标识符 主键 自动生成
        /// </summary>
        [Key] public int User_Id { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        /// 
        /// <summary>
        /// 手机号
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// 用户注册时间
        /// </summary>
        public string Face_url { get; set; }
    }
}
