﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyApiTest.Models
{
    public class CommonResult
    {
        public string Msg { get; set; }

        public static CommonResult OK()
        {
            return new CommonResult { Msg = "ok" };
        }
        
    }
}
