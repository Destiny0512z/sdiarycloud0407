﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace MyApiTest.Models
{
    public class AddModel
    {
        [Key] public int UserId { get; set; }

        /// <summary>
        /// 用户名
        /// </summary>
        public string Username { get; set; }


        /// <summary>
        /// 密码
        /// </summary>
        public string Face_url { get; set; }

        /// <summary>
        /// 手机号
        /// </summary>
        public string Content { get; set; }




  
    }
}
