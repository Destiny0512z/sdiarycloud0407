﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyApiTest.Models
{
    public class GetUserMessages
    {
        public int UserId { get; set; }
    }
}
