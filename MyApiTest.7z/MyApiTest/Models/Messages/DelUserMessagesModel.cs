﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyApiTest.Models
{
    public class DelUserMessagesModel
    {
        public int MessageId { get; set; }
        public int User_Id { get; set; }


    }
}
