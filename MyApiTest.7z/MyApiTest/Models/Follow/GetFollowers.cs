﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyApiTest.Models.Follow
{
    public class GetFollowers
    {
        public int FollowId { get; set; }
        /// <summary>
        /// 传入自己的Id，然后返回粉丝列表
        /// </summary>
        
    }
}
