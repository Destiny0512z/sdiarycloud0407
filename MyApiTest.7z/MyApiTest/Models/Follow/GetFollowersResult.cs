﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MyApiTest.Models.Follow
{
    public class GetFollowersResult
    {
        public string Username { get; set; }
        public string Face_url { get; set; }

    }
}
